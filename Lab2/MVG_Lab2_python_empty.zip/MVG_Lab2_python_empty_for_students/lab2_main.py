from lab2_section2 import Section2
from lab2_section3 import Section3
from lab2_section4 import Section4
from lab2_section5 import Section5

if __name__ =='__main__':

    # Run Lab 2 sections
    Section2()
    Section3()
    Section4()
    Section5()